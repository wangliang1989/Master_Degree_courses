function y=iter(dyfun,x,y,h)
y0=y;e=1e-4;K=1e+4;
y=y+h*feval(dyfun,x,y);
y1=y+2*e;k=1;
while abs(y-y1)>e
    y1=y;
    y=y0+h*feval(dyfun,x,y);
    k=k+1;if k>K,error('������ɢ');
    end
end