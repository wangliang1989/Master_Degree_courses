function fy=vdp(t,x)
fy=[x(2);7*(1-x(1)^2)*x(2)-x(1)];
