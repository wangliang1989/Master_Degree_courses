fun=inline('x^2+x-y');  
[t,y]=ode45(fun,[0,1],1);
