y0=[1;0]
[t,x]=ode45(@vdp,[0,40],y0);
y=x(:,1);dy=x(:,2);
plot(t,y,t,dy)
