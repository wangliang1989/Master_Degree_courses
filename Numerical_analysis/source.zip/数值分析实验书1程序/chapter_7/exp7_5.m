format short
funfcn=inline('x-y','x','y');
[x,y]=Adams4x(funfcn,0,1,0.1,10)
