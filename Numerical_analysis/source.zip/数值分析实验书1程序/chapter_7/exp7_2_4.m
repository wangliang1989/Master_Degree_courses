dyfun=inline('x^2+x-y');
[x,y1]=nark4(dyfun,[0,1],1,0.1)
plot(x,y1,'b*-')
hold on
[x,y2]=ode45(dyfun,[0,1],1)
plot(x,y2,'ro-')
hold on
y3=inline('x^2-x+1')
fplot(y3,[0,1],'k')
legend('RK4��','RKF45��','���Ž�')
