dyfun=inline('x^2+x-y');
[x,y]=nark4(dyfun,[0,1],1,0.1);
