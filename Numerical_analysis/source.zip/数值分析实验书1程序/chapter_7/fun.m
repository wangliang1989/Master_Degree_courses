function f=fun(x,y)
f=1+y.^2;