funfcn=inline('x+y');
[x,y]=Adams4y(funfcn,0,1,0.1,10)
