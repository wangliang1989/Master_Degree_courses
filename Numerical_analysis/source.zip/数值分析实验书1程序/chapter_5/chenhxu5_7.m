x = 0:10;  
y = sin(x);
xt = 0:.25:10;
yt = spline(x,y,xt);
xx=0:0.02:10;
yy=sin(xx);
plot(xt,yt,'-b',xx,yy,'r-.',x,y,'o')
legend('spline','sine','(x_k,y_k)')
