xt=-1:0.05:5;
y=exp(xt);
plot(xt,y,'k-')
hold on

S1=Approx_Square(-1,5,2)
yt=zeros(1,length(xt));
for i=1:2
    yt=yt+S1(i+1)*xt.^i;
end
yt=yt+S1(1);
plot(xt,yt,'r-')
hold on

S2=Approx_Square(-1,5,3)
yt=zeros(1,length(xt));
for i=1:3
    yt=yt+S2(i+1)*xt.^i;
end
yt=yt+S2(1);
plot(xt,yt,'b-.')
hold on
legend('y=e^x','2�����ƽ���ƽ�','3�����ƽ���ƽ�')
xlabel('x')
