x=[0.4 0.5 0.6 0.7 0.8];
y=[0.6325 0.7071 0.7746 0.8367 0.8944];
xt=0.54;
[yt,N] = NewtInterp(x,y,xt)
% ��ͼ
z=0.1:0.05:2;
yz= subs(N,'t',z);  %�����ֵ�㴦�ĺ���ֵ
figure;
plot(z,sqrt(z),'--r',z,yz,'-b')
hold on
plot(x,y,'marker','+')
hold on
plot(xt,yt,'marker','o')
h=legend('$\sqrt{x}$','Newton','$(x_k,y_k)$','$x=0.54$');
set(h,'Interpreter','latex')
xlabel('x')
ylabel('y')
