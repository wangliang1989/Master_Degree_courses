function  [m,u,index]=pow(A,ep,it_max)
if nargin<3 it_max=100;end
if nargin<2 ep=1e-5;end
n=length(A);u=ones(n,1);
index=0;k=0;m1=0;
while k<=it_max
v=A*u;[vmax,i]=max(abs(v));
 m=v(i);u=v/m;
if abs(m-m1)<ep
index=1;break;
end
m1=m;k=k+1;
end
