A=[2 -1 0;-1 2 -1;0 -1 2];
[m,u,index]=pow_inv(A,1e-4)
