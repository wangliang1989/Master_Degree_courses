A=[0 4 1;1 1 1;0 3 2];
 [Q,R]=QR_Householder(A)
A=[1 2 1 2;2 1 2 -1;1 2 0 3;2 -1 3 1]; 
 [Q,R]=QR_Householder(A)