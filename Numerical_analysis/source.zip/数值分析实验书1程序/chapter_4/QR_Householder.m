function [Q,R]=QR_Householder(A)
[r,c]=size(A);
R=A;
Q=eye(r);
for j=1:c-1
    w=sign(Q(1))*R(j:r,j);
    w(1,1)=w(1,1)-norm(w);
    w=w/norm(w);
    H=eye(c);
    H(j:r,j:c)=eye(c-j+1)-2*w*w';
    R=H*R;
    Q=Q*H;
end
