function [D,R,index,it]=Jacobi(A,ep,t_max)
if nargin<2
    ep=1e-5;
end
if nargin<3
    t_max=100;
end
n=length(A);
R=eye(n);
index=0;
it=0;
while it<t_max
Amax=0;
for q=1:n-1
    for k=q+1:n
        if abs(A(q,k))>Amax
            Amax=abs(A(q,k));
            i=q;
            j=k;
        end
    end
end
if Amax<ep
    index=1;
    break;
end
d=(A(j,j)-A(i,i))/(2*A(i,j));
if abs(d)<1e-10
    t=1;
else t=sign(d)/(abs(d)+sqrt(d^2+1));
end
c=1/sqrt(t^2+1);
s=c*t;
for p=1:n
    if p==i
        Aii=A(i,i)*c^2+A(j,j)*s^2-2*A(i,j)*s*c;
        Ajj=A(i,i)*s^2+A(j,j)*c^2+2*A(i,j)*s*c;
        Aij=(A(i,i)-A(j,j))*s*c+A(i,j)*(c^2-s^2);
        A(i,j)=Aij;
        A(j,i)=A(i,j);
        A(i,i)=Aii;
        A(j,j)=Ajj;
    elseif  p~=j     
        Aip=A(i,p)*c-A(j,p)*s;
        Api=Aip;
        Ajp=A(i,p)*s+A(j,p)*c;
        Apj=Ajp;
        A(i,p)=Aip;
        A(p,i)=Aip;
        A(j,p)=Ajp;
        A(p,j)=Ajp;       
    end
    Rpi=R(p,i)*c-R(p,j)*s;
    Rpj=R(p,i)*s+R(p,j)*c;
    R(p,i)=Rpi;
    R(p,j)=Rpj;
end
    it=it+1;
end
D=diag(diag(A));
