global ki;ki=0;
I=dblquad('fxy',-2,2,-1,1)
ki
