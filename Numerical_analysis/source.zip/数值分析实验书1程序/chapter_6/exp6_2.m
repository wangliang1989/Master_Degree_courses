x=0:0.125:1;y=x./(x.^2+4);
I=T_quad(x,y)
x=0:0.125:1;y=x./(x.^2+4);
I=S_quad(x,y)
x=1:2:9;y=sqrt(x);
I=T_quad(x,y)
x=1:2:9;y=sqrt(x);
I=S_quad(x,y)
