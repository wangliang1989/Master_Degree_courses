f1=@(x)1./(1+x.^2);
[y1,Ck,Ak]=NewtonCotes(f1,-1,1,1)
[y2,Ck,Ak]=NewtonCotes(f1,-1,1,2)
[y3,Ck,Ak]=NewtonCotes(f1,-1,1,4)
[y4,Ck,Ak]=NewtonCotes(f1,-1,1,8)