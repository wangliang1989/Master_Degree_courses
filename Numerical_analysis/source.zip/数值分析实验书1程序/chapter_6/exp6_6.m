y1=quad2d(@(x,y) exp(sin(x)).*log(y),10,20,@(x)5*x,@(x)x.^2)
y2 =quadl(@(x) arrayfun(@(x) quadl(@(y)exp(sin(x)).*log(y),5*x,x.^2),x), 10,20)
y3 = dblquad(@(x,y)exp(sin(x)).*log(y).*(y>=5*x & y<=x.^2),10,20,50,400)
q = dblquad(fun,xmin,xmax,ymin,ymax,tol,method)