function I=T_quad_iter(fun,a,b,ep)
if nargin<4 ep=1e-5;end;
N=1;h=b-a;
T=h/2*(feval(fun,a)+feval(fun,b));
while 1
h=h/2;I=T/2;
for k=1:N
  I=I+h*feval(fun,a+(2*k-1)*h);
end
if abs(I-T)<ep
  break;
end
N=2*N;T=I;
end
