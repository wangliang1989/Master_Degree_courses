fun=@(x)exp(x).*cos(x); 
quadl(fun,0,pi) 
[ql,Ak,xk]=guasslegendre(fun,0,pi,7)
