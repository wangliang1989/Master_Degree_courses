f3=@(x)x.*sqrt(x);
y=mulNewtonCotes(f3,1,9,1,4)
f3=@(x)x.*sqrt(x);
y=mulNewtonCotes(f3,1,9,4,4)
