fun=inline('sqrt(x)');
z=romberg(fun,1,9,1e-5)
