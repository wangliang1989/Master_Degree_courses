x0=[0;0];ep=1e-5;M=100;
[x k t index]=Broyden1(@NewdonF,@NewdonDF,x0,ep,M)
