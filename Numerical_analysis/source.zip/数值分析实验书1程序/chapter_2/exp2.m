phi=inline('(x+1)^(1/3)');
[x_star,index,it]=iterate(phi,1.5)

