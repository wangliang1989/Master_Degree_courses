fun=inline('[x^3-x-1,3*x^2-1]');
[x_star,index,it]=Newton(fun,1.5)