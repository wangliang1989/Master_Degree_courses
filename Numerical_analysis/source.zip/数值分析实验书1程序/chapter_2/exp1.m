fun=inline('x^3-x-1');
[x_star,inedx,it]=bisect(fun,1,2)
