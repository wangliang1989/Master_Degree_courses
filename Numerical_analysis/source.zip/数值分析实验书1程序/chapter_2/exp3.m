phi=inline('x^3-1');
[x_star,index,it]=steffensen(phi,1.5)
