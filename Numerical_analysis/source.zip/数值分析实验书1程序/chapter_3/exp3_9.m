A=[4 -1 1;-1 4.25 2.75;1 2.75 3.5];b=[1 1 1]' ;
[L,D,x,y,index]=LDL_Decom(A,b)
