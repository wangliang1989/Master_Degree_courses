A=[1 2 3;4 5 6;7 8 0];b=[1 1 1]' ;
[x,index] = GaussJor(A, b)
