A=[4 3 0;3 5 -1;0 -1 4];b=[24 30 -24]';ep=1e-5;it_max=100;
[x,k,index]=Jacobi(A,b,ep,it_max)
