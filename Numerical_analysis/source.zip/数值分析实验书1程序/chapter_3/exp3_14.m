A=[3 2 1;-1 4 1;2 -3 8];
b=[-12;10;3];
w=0.7;
ep=1e-5;
it_max=200;
[x,k,index]=SOR(A,b,w,ep,it_max)