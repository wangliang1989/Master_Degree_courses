A=[-4 1 0;1 -4 1;0 1 -4];d=[1 1 1]' ;
x=zhuiganfa(A,d)

